someNumber = 10

if(someNumber > 0):
    print("Over zerro")
elif(someNumber < 0):
    print("Bellow zerro")
else:
    print("zerro")
